=== Css Modifications For Neve (Beta) ===
Contributors: AspieSoft
Tags: css, js, neve, theme, modify, sticky-header
Requires at least: 3.0.1
Tested up to: 5.9
Stable tag: 0.4.0
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://buymeacoffee.aspiesoft.com

Css and JS modifications for The Neve Wordpress Theme.

== Installation ==
1. Upload plugin to the /wp-content/plugins
2. Activate the plugin through the "Plugins" menu in WordPress
3. Enjoy

== Changelog ==

= 1.0 =
First Version

== Upgrade Notice ==

= 1.0 =
First Version
